module com.example.testprojectforjavafx {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.testprojectforjavafx to javafx.fxml;
    exports com.example.testprojectforjavafx;
}