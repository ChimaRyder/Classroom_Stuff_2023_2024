package com.example.testprojectforjavafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HelloController {
    List<String> users = List.of("user1", "user2", "user3");
    List<String> password = List.of("123456", "654321", "password");
    List<String> colors = List.of("ffffff", "ffffff", "ffffff");
    int current_user;

    @FXML
    private TextField user_field;
    @FXML
    private TextField password_field;
    @FXML
    private GridPane loginPane;
    @FXML
    private GridPane homePane;
    @FXML
    private ColorPicker colorPicker;

    @FXML
    protected void onSignInClick() throws IOException {
        if (users.contains(user_field.getText()) && password.contains(password_field.getText())) {
            current_user = users.indexOf(user_field.getText());
            FXMLLoader f = new FXMLLoader(HelloApplication.class.getResource("home-view.fxml"));
            Parent homeView = f.load();

            try{
                BufferedWriter bw = new BufferedWriter(new FileWriter(Objects.requireNonNull(getClass().getResource("hello.css")).getPath()));

                bw.write(".button { -fx-background-color: #"+ colors.get(current_user) + "; }");
                bw.close();
            }catch (IOException e) {
                e.printStackTrace();
            }

            AnchorPane p = (AnchorPane) loginPane.getParent();
            p.getChildren().remove(loginPane);
            p.getChildren().add(homeView);
            String css = this.getClass().getResource("hello.css").toExternalForm();
            p.getStylesheets().add(css);
        } else {
            Alert invalid = new Alert(Alert.AlertType.WARNING, "INVALID USER OR PASSWORD");
            invalid.show();
        }
    }

    @FXML
    protected void onSignOutClick() throws IOException {
        FXMLLoader f = new FXMLLoader(HelloApplication.class.getResource("login-view.fxml"));
        Parent loginView = f.load();
        AnchorPane p = (AnchorPane) homePane.getParent();
        p.getChildren().remove(homePane);
        p.getChildren().add(loginView);
    }

    @FXML
    protected void onColorChange() {
        colors = new ArrayList<>(colors);
        colors.remove(current_user);
        colors.add(current_user, colorPicker.getValue().toString().substring(2, 8));
    }
}